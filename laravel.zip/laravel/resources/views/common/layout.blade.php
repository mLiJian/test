<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document @yield('title')</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('static/bootstrap/css/bootstrap.min.css') }}">
	@section('style')

	@show
</head>
<body>

@section('header')
	<div class="container" style="background:pink;margin-bottom:50px;">
		<h2>larvel</h2>
		<p>学生统计</p>
	</div>


@show

@section('content')


@show

@section('footer')
	<div class="container" style="position:absolute;bottom:0px;left:96px;height:50px;background:pink;">
		<span style='color:#000;'>@2016 sudent</span>
	</div>

@show

</body>
</html>