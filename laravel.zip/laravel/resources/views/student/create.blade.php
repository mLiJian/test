@extends('common.layout')

@section('content')
<div class="container">
	<form role="form" method="post" action="{{url('student/save')}}">
	  <div class="form-group">
	    <label for="exampleInputEmail1">name</label>
	    <input type="text" name="name" class="form-control" placeholder="name">
	  </div>
	  <div class="form-group">
	    <label for="exampleInputPassword1">age</label>
	    <input type="text" name="age" class="form-control" id="exampleInputPassword1" placeholder="age">
	  </div>
	  <div class="radio">
	    <label>
	      <input type="radio" name="sex" value="1"> 男
	    </label>
	  </div>
	  <div class="radio">
		<label>
	      <input type="radio" name="sex" value="0"> 女
	    </label>
	  </div>

	  <button type="submit" class="btn btn-default">Submit</button>
	</form>
</div>

@stop