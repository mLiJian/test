@extends('common.layout')

@section('content')
	<div class="container">
		<a href="{{url('student/create')}}" class="btn btn-lg btn-primary">添加学生</a>
		<table class="table table-hover">
			<thead>
				<tr style="background:gray;">
					<td>ID</td>
					<td>姓名</td>
					<td>年龄</td>
					<td>性别</td>
					<td>添加时间</td>
					<td>操作</td>
				</tr>
			</thead>
			<tbody>
				@foreach($students as $student)
				<tr>
					<td>{{ $student->id }}</td>
					<td>{{ $student->name }}</td>
					<td>{{ $student->age }}</td>
					<td>{{ $student->sex==1?'男':'女' }}</td>
					<td>{{ date('Y-m-d',$student->create_at) }}</td>
					<td>
						<a href="{{ url('student/update',['id'=>$student->id]) }}">修改</a>
						<a href="{{ url('student/delete',['id'=>$student->id]) }}">删除</a>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>

	<div class="container">
		<div class="pull-right">
			{{ $students->render() }}
		</div>
	</div>
@stop