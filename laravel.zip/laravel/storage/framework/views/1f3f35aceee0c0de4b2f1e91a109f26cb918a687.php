<?php $__env->startSection('content'); ?>
	<div class="container">
		<a href="<?php echo e(url('student/create')); ?>" class="btn btn-lg btn-primary">添加学生</a>
		<table class="table table-hover">
			<thead>
				<tr style="background:gray;">
					<td>ID</td>
					<td>姓名</td>
					<td>年龄</td>
					<td>性别</td>
					<td>添加时间</td>
					<td>操作</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach($students as $student): ?>
				<tr>
					<td><?php echo e($student->id); ?></td>
					<td><?php echo e($student->name); ?></td>
					<td><?php echo e($student->age); ?></td>
					<td><?php echo e($student->sex==1?'男':'女'); ?></td>
					<td><?php echo e(date('Y-m-d',$student->create_at)); ?></td>
					<td>
						<a href="<?php echo e(url('student/update',['id'=>$student->id])); ?>">修改</a>
						<a href="<?php echo e(url('student/delete',['id'=>$student->id])); ?>">删除</a>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="container">
		<div class="pull-right">
			<?php echo e($students->render()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>