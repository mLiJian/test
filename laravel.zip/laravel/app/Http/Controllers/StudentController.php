<?php
namespace App\Http\Controllers;

use App\Student;

class StudentController extends Controller
{
	public function index(){

		$students = Student::paginate(2);
		//var_dump($students);exit;
		return view('student.index',[
				'students'=>$students,
			]);
	}


	public function create(){

		return view('student.create');
	}

	public function save(){

		//var_dump($_POST);exit;
		$student = new Student();
		$student->name=$_POST['name'];
		$student->age=$_POST['age'];
		$student->sex=$_POST['sex'];

		if($student->save()){
			return redirect('student/index');
		}else{
			return redirect()->back();
		}
	} 

	public function update($id){
		//echo 111;exit;
		$student = Student::find($id);
		return view('student.update',[
				'student'=>$student
			]);
	}


	public function delete($id){
		$student = Student::find($id);
		if($student->delete()){
			return redirect('student/index');
		}
	}





}


















?>